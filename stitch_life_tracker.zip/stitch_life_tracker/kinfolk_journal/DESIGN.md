---
name: Kinfolk Journal
colors:
  surface: '#fff8f5'
  surface-dim: '#f7d3bc'
  surface-bright: '#fff8f5'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#fff1e9'
  surface-container: '#ffeadd'
  surface-container-high: '#ffe3d1'
  surface-container-highest: '#ffdcc5'
  on-surface: '#2a1709'
  on-surface-variant: '#434840'
  inverse-surface: '#412c1c'
  inverse-on-surface: '#ffede3'
  outline: '#74796f'
  outline-variant: '#c3c8bd'
  surface-tint: '#4c6544'
  primary: '#435c3c'
  on-primary: '#ffffff'
  primary-container: '#5b7553'
  on-primary-container: '#ddfad0'
  inverse-primary: '#b2cfa7'
  secondary: '#98462c'
  on-secondary: '#ffffff'
  secondary-container: '#fd9575'
  on-secondary-container: '#752c14'
  tertiary: '#764e00'
  on-tertiary: '#ffffff'
  tertiary-container: '#966400'
  on-tertiary-container: '#fff0df'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#cdebc1'
  primary-fixed-dim: '#b2cfa7'
  on-primary-fixed: '#092007'
  on-primary-fixed-variant: '#354d2e'
  secondary-fixed: '#ffdbd0'
  secondary-fixed-dim: '#ffb59e'
  on-secondary-fixed: '#3a0b00'
  on-secondary-fixed-variant: '#7a2f17'
  tertiary-fixed: '#ffddb2'
  tertiary-fixed-dim: '#fdba54'
  on-tertiary-fixed: '#291800'
  on-tertiary-fixed-variant: '#624000'
  background: '#fff8f5'
  on-background: '#2a1709'
  surface-variant: '#ffdcc5'
typography:
  display-lg:
    fontFamily: Newsreader
    fontSize: 48px
    fontWeight: '400'
    lineHeight: 56px
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: Newsreader
    fontSize: 34px
    fontWeight: '400'
    lineHeight: 42px
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: Newsreader
    fontSize: 32px
    fontWeight: '500'
    lineHeight: 40px
  headline-md:
    fontFamily: Newsreader
    fontSize: 26px
    fontWeight: '500'
    lineHeight: 34px
  headline-sm:
    fontFamily: Newsreader
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  title-md:
    fontFamily: Newsreader
    fontSize: 18px
    fontWeight: '500'
    lineHeight: 24px
  body-lg:
    fontFamily: Newsreader
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Newsreader
    fontSize: 15px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Newsreader
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 20px
  label-lg:
    fontFamily: Courier Prime
    fontSize: 14px
    fontWeight: '700'
    lineHeight: 20px
    letterSpacing: 0.04em
  label-md:
    fontFamily: Courier Prime
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
    letterSpacing: 0.02em
  label-sm:
    fontFamily: Courier Prime
    fontSize: 11px
    fontWeight: '400'
    lineHeight: 14px
    letterSpacing: 0.05em
  data-mono:
    fontFamily: Courier Prime
    fontSize: 16px
    fontWeight: '700'
    lineHeight: 22px
    letterSpacing: -0.01em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1.25rem
  gutter-desktop: 2rem
  margin: 1rem
  margin-desktop: 3rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

This design system draws from 1970s analog stationery, personal commonplace notebooks, and tactile scrapbook design. It treats digital self-tracking not as an austere analytical dashboard, but as a treasured physical companion—an archival notebook filled with aged paper stock, washi tape labels, rubber-stamped milestones, and typewriter-tabulated expenditures.

The target audience is students, young creatives, and mindful individuals navigating the delicate balance of budgeting, daily habits, creative work, and mental health. The emotional response should be disarming, grounded, and deeply restorative: relieving the anxiety typically induced by productivity apps and financial logs through tactile warmth, imperfect organic textures, and intentional pacing.

Key visual attributes include:
- **Paper-First Tactility:** Tiered cream, linen, and kraft paper surfaces with fibrous warmth.
- **Physical Assemblage:** Tape strips, stamped indicators, polaroid frames, and clipped notes.
- **Analog Notation:** A union of literary serifs, mechanical typewriter logs, and editorial balance.

## Colors

The color palette anchors to 1970s printed ephemera and natural earth pigments, rejecting pure blacks, harsh whites, and saturated synthetic tones.

- **Primary (`#5B7553` - Sage Green):** Used for constructive actions, positive habit streaks, growth milestones, and foundational focus points.
- **Secondary (`#C06548` - Soft Terracotta):** Denotes expense deductions, urgent reflections, critical habits, and energetic callouts.
- **Tertiary (`#D99B38` - Mustard Ochre):** Applied to warm highlights, active toggles, bookmarks, and attention badges.
- **Neutral Primary (`#483222` - Kraft Roast):** Replaces synthetic black across all primary text, borders, fine ink rules, and rubber stamp icons.
- **Canvas Base (`#FBF7EE` - Cream Vellum):** The foundational page background mimicking unbleached archival paper.
- **Supporting Accents:** 
  - Faded Denim (`#4D6A7A`): Secondary categorization, savings buckets, and historical logs.
  - Soft Rose Tint (`#E8CEC4`): Subtle surface fills, mood-tracker accents, and pinned margins.

Surfaces rely on tinted opacity steps of Kraft Roast and Rose Tint over Cream Vellum to create natural paper fiber depth rather than artificial digital grays.

## Typography

The typography system sets up a deliberate dialogue between two worlds: the literary, reflective intimacy of a personal diary (`Newsreader`) and the pragmatic record-keeping of a desktop typewriter (`Courier Prime`).

- **Display & Headlines (`Newsreader`):** Emphasize italicized, humanistic forms for inspirational prompts, journal dates, and emotional check-in inquiries. Generous line-heights prevent cramped feelings on screen.
- **Body Text (`Newsreader`):** Used for long-form reflections, habit notes, and guided coaching sentences. Ensures a bookish reading cadence.
- **Labels, Metrics & Financial Data (`Courier Prime`):** Every monetary figure, percentage, habit counter, button label, and category tag is rendered in Courier Prime. This simulates ledger stamping, grocery receipts, and mechanical tabulation, providing stark, honest contrast to reflective prose.

## Layout & Spacing

Layouts follow an asymmetrical, tactile collage arrangement over a structured underlying grid. 

- **Grid Architecture:** Desktop views utilize an 8-column layout allowing multi-card scrapbooking (journal entry alongside expense ledger and habit streak). Mobile compresses into a focused, single-column scroll reminiscent of an open, narrow-ruled notebook.
- **Rhythm & Flow:** Margins mimic physical sheet margins—wide left gutters simulate the spine of a spiral or ring-bound notebook. 
- **Card Clustering:** Rather than rigid, uniformly spaced tiles, elements may overlap slightly using negative offsets (`-4px` to `-8px`) combined with subtle rotation (between `-1deg` and `+1.5deg`) on secondary cards to preserve the scrapboard aesthetic without breaking vertical flow.

## Elevation & Depth

Visual hierarchy rejects digital blur elevations and synthetic colored dropshadows. Depth is conveyed exclusively through physical paper stacking:

- **Base Sheet (Elevation 0):** Unbleached cream canvas (`#FBF7EE`) with an optional fine grain or subtle dotted rule.
- **Layered Note / Card (Elevation 1):** Offset paper stock rendered with a distinct, warm ambient shadow: `1px 2px 0px rgba(72, 50, 34, 0.12), 0px 4px 12px rgba(72, 50, 34, 0.06)`. Edge definitions use a soft 1px solid ink line (`rgba(72, 50, 34, 0.15)`).
- **Lifted Ephemera / Overlays (Elevation 2):** Modal sheets, active polaroid inspections, and dropdown receipts feature an increased physical drop: `2px 6px 0px rgba(72, 50, 34, 0.18), 0px 12px 24px rgba(72, 50, 34, 0.1)`.
- **Washi Tape & Fasteners:** Small horizontal and diagonal tape segments rendered with semi-transparent overlays (`rgba(217, 155, 56, 0.35)` or muted sage) visually "fasten" cards to the parent surface, acting as functional anchors for category tags and status chips.

## Shapes

The shape system is subtly softened (`0.25rem` base) to evoke hand-cut paper, vintage index cards, and cardstock rather than high-tech pill geometry or cold, machine-sharp razor corners.

- **Standard Cards & Ledger Sheets:** Subtly rounded corners (`4px`) with crisp 1px borders.
- **Polaroid Frames:** Asymmetrical padding—uniform `12px` top, left, and right margins with a hefty `36px` bottom chin meant for handwritten notes and dates.
- **Washi Tape Elements:** Straight-edge rectangles with jagged, serrated vertical ends created via mask clips to evoke torn tape rolls.
- **Stamps:** Round or ovular double-lined borders with intentional minor ink breaks.

## Components

### Buttons
- **Primary Button:** Deep Sage Green (`#5B7553`) fill with unbleached cream label (`#FBF7EE`) set in Courier Prime uppercase. Border is an inset 1px ink rule. Hover states darken slightly; active click mimics being pressed into the page with a `translate(1px, 1px)` offset and loss of ambient bottom shadow.
- **Secondary Button:** Cream paper container with a 1.5px solid Kraft Roast border (`#483222`) and typewriter label.
- **Tertiary / Action Link:** Handwritten-style serif text with a dashed bottom border mimicking a pen underline.

### Cards & Ledger Tiles
- **Kraft Log Cards:** Textured medium-brown surfaces (`#EADCC9`) designated for financial entries, with columns spaced via monospaced tabular figures.
- **Polaroid Cards:** Pure white-cream framing around photographs or habit progression charts with wide handwritten caption margins at the bottom.

### Inputs & Form Fields
- **Fields:** Designed as ruled notebook lines rather than enclosed boxes. A solid single bottom line (`rgba(72, 50, 34, 0.3)`) where user typing sits directly on the rule in Courier Prime.
- **Focus State:** The bottom rule thickens to 2px in Sage Green with a faint ochre highlight tint across the line.

### Checkboxes & Habit Trackers
- **Checkboxes:** Imperfect hand-drawn square borders (`18px`). When toggled, an authentic stamp-like checkmark fills the box in Soft Terracotta or Sage Green with a fast ink-bleed animation.
- **Habit Streak Grid:** Rendered as mini calendar blocks stamped with circular ink impressions for completed days.

### Chips & Washi Badges
- **Washi Chips:** Translucent rectangular tags pinned across borders, carrying category labels in all-caps Courier Prime (`0.75rem`).
- **Rubber Stamp Badges:** Circular, rotated indicators (`"PAID"`, `"COMPLETED"`, `"REFLECTED"`) rendered in terracotta or mustard ink with weathered stencil typography.